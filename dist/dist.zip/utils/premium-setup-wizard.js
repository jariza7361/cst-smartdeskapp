// Premium Setup Wizard with Enhanced Functionality
class PremiumSetupWizard {
  constructor() {
    this.currentStep = 1;
    this.totalSteps = 3;
    this.formData = {};
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.updateProgress();
    this.loadSavedData();
    this.setupThemeSelector();
    this.setupValidation();
  }

  setupEventListeners() {
    const nextBtn = document.getElementById('wizardNext');
    const prevBtn = document.getElementById('wizardPrev');
    const saveBtn = document.getElementById('wizardSave');
    const wizard = document.getElementById('setup-wizard');

    if (nextBtn) {
      nextBtn.addEventListener('click', () => this.nextStep());
    }

    if (prevBtn) {
      prevBtn.addEventListener('click', () => this.prevStep());
    }

    if (saveBtn) {
      saveBtn.addEventListener('click', () => this.saveSettings());
    }

    // Auto-open handled by main app initialization

    // Setup button to open wizard
    const setupBtn = document.getElementById('openSettingsTop');
    if (setupBtn) {
      setupBtn.addEventListener('click', () => {
        if (wizard) {
          wizard.showModal();
        }
      });
    }

    // Form input listeners for real-time validation
    this.setupInputListeners();
  }

  setupInputListeners() {
    const inputs = document.querySelectorAll('#wizardForm input, #wizardForm select');
    inputs.forEach(input => {
      input.addEventListener('input', () => {
        this.validateField(input);
        this.updateFormData();
      });

      input.addEventListener('blur', () => {
        this.validateField(input);
      });
    });
  }

  validateField(field) {
    const value = field.value.trim();
    const fieldName = field.id;
    let isValid = true;
    let message = '';

    // Remove existing validation styling
    field.classList.remove('field-error', 'field-success');

    switch (fieldName) {
      case 'wName':
        isValid = value.length >= 2 && value.includes(' ');
        message = isValid ? '' : 'Please enter your full name';
        break;
      case 'wEmpId':
        isValid = /^[A-Z0-9]{4,10}$/.test(value.toUpperCase());
        message = isValid ? '' : 'Employee ID should be 4-10 characters (letters/numbers)';
        break;
      case 'wExt':
        isValid = /^[0-9]{3,5}$/.test(value);
        message = isValid ? '' : 'Extension should be 3-5 digits';
        break;
    }

    // Add validation styling
    if (field.required && value) {
      field.classList.add(isValid ? 'field-success' : 'field-error');
    }

    // Show/hide validation message
    this.showFieldMessage(field, message, isValid);

    return isValid;
  }

  showFieldMessage(field, message, isValid) {
    let messageEl = field.parentNode.querySelector('.field-message');
    
    if (message) {
      if (!messageEl) {
        messageEl = document.createElement('div');
        messageEl.className = 'field-message';
        field.parentNode.appendChild(messageEl);
      }
      messageEl.textContent = message;
      messageEl.className = `field-message ${isValid ? 'success' : 'error'}`;
    } else if (messageEl) {
      messageEl.remove();
    }
  }

  setupThemeSelector() {
    const themeOptions = document.querySelectorAll('.theme-option');
    const themeInput = document.getElementById('wTheme');

    themeOptions.forEach(option => {
      option.addEventListener('click', () => {
        // Remove selected class from all options
        themeOptions.forEach(opt => opt.classList.remove('selected'));
        
        // Add selected class to clicked option
        option.classList.add('selected');
        
        // Update hidden input
        if (themeInput) {
          themeInput.value = option.dataset.theme;
        }

        // Preview theme immediately
        this.previewTheme(option.dataset.theme);
      });
    });
  }

  previewTheme(themeName) {
    const body = document.body;
    
    // Remove existing theme classes
    body.classList.remove('theme-light', 'theme-dark', 'theme-glass', 'theme-macos', 'theme-asurion');
    
    // Add new theme class
    body.classList.add(`theme-${themeName}`);
    
    // Show preview notification
    this.showNotification(`Theme preview: ${themeName.charAt(0).toUpperCase() + themeName.slice(1)}`, 'info');
  }

  nextStep() {
    if (this.validateCurrentStep()) {
      if (this.currentStep < this.totalSteps) {
        this.currentStep++;
        this.updateStep();
        this.updateProgress();
      }
    }
  }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.updateStep();
      this.updateProgress();
    }
  }

  validateCurrentStep() {
    const currentStepEl = document.querySelector(`.wizard-step[data-step=\"${this.currentStep}\"]`);
    const requiredFields = currentStepEl.querySelectorAll('input[required], select[required]');
    let isValid = true;

    requiredFields.forEach(field => {
      if (!this.validateField(field)) {
        isValid = false;
      }
    });

    if (!isValid) {
      this.showNotification('Please fill in all required fields correctly', 'error');
    }

    return isValid;
  }

  updateStep() {
    // Hide all steps
    document.querySelectorAll('.wizard-step').forEach(step => {
      step.classList.remove('active');
    });

    // Show current step
    const currentStepEl = document.querySelector(`.wizard-step[data-step=\"${this.currentStep}\"]`);
    if (currentStepEl) {
      currentStepEl.classList.add('active');
    }

    // Update navigation buttons
    const prevBtn = document.getElementById('wizardPrev');
    const nextBtn = document.getElementById('wizardNext');
    const saveBtn = document.getElementById('wizardSave');

    if (prevBtn) {
      prevBtn.disabled = this.currentStep === 1;
    }

    if (nextBtn && saveBtn) {
      if (this.currentStep === this.totalSteps) {
        nextBtn.style.display = 'none';
        saveBtn.style.display = 'block';
      } else {
        nextBtn.style.display = 'block';
        saveBtn.style.display = 'none';
      }
    }
  }

  updateProgress() {
    const progressFill = document.getElementById('wizardProgress');
    if (progressFill) {
      const percentage = (this.currentStep / this.totalSteps) * 100;
      progressFill.style.width = `${percentage}%`;
    }
  }

  updateFormData() {
    const formElements = document.querySelectorAll('#wizardForm input, #wizardForm select');
    formElements.forEach(element => {
      if (element.type === 'checkbox') {
        this.formData[element.id] = element.checked;
      } else {
        this.formData[element.id] = element.value;
      }
    });
  }

  saveSettings() {
    this.updateFormData();
    
    // Validate all steps
    let allValid = true;
    for (let step = 1; step <= this.totalSteps; step++) {
      const stepEl = document.querySelector(`.wizard-step[data-step=\"${step}\"]`);
      const requiredFields = stepEl.querySelectorAll('input[required], select[required]');
      
      requiredFields.forEach(field => {
        if (!this.validateField(field)) {
          allValid = false;
        }
      });
    }

    if (!allValid) {
      this.showNotification('Please complete all required fields', 'error');
      return;
    }

    // Show saving animation
    this.showSavingAnimation();

    // Save process
    try {
      // Save to localStorage
      localStorage.setItem('cst_setup_data', JSON.stringify(this.formData));
      localStorage.setItem('cst-setup-complete', 'true');
      localStorage.setItem('cst_setup_completed', 'true');

      // Update UI with saved data
      this.updateUIWithSettings();

      // Show success message
      this.showNotification('Settings saved successfully!', 'success');

      // Close wizard after short delay
      setTimeout(() => {
        const wizard = document.getElementById('setup-wizard');
        if (wizard) {
          wizard.close();
        }
      }, 1500);

    } catch (error) {
      console.error('Error saving settings:', error);
      this.showNotification('Error saving settings. Please try again.', 'error');
      this.resetSaveButton();
    }
  }

  resetSaveButton() {
    const saveBtn = document.getElementById('wizardSave');
    if (saveBtn) {
      saveBtn.textContent = 'Complete Setup';
      saveBtn.disabled = false;
    }
  }

  showSavingAnimation() {
    const saveBtn = document.getElementById('wizardSave');
    if (saveBtn) {
      const originalText = saveBtn.textContent;
      saveBtn.textContent = 'Saving...';
      saveBtn.disabled = true;
      
      // Add loading animation
      saveBtn.innerHTML = `
        <div class="saving-spinner"></div>
        Saving Settings...
      `;
    }
  }

  updateUIWithSettings() {
    const data = this.formData;
    
    // Update header with user info
    const userNameEl = document.querySelector('.user-name');
    if (userNameEl && data.wName) {
      userNameEl.textContent = data.wName;
    }

    // Update coach info
    const coachInfo = document.querySelector('.user-meta span');
    if (coachInfo && data.wCoach) {
      const coachName = data.wCoach.replace('.', ' ').replace(/\\b\\w/g, l => l.toUpperCase());
      coachInfo.textContent = `Coach: ${coachName}`;
    }

    // Apply selected theme
    if (data.wTheme) {
      this.previewTheme(data.wTheme);
    }

    // Update notification preferences
    this.updateNotificationSettings(data);
  }

  updateNotificationSettings(data) {
    const notificationTypes = {
      notifyEscalations: 'escalation',
      notifyPolicies: 'policy',
      notifyCoach: 'coach',
      notifySystem: 'system'
    };

    Object.entries(notificationTypes).forEach(([key, type]) => {
      if (data[key] === false) {
        // Disable this type of notification
        console.log(`Disabled ${type} notifications`);
      }
    });
  }

  loadSavedData() {
    // Only load saved data if setup is already completed
    const setupComplete = localStorage.getItem('cst-setup-complete') || localStorage.getItem('cst_setup_completed');
    if (setupComplete) {
      const savedData = localStorage.getItem('cst_setup_data');
      if (savedData) {
        try {
          this.formData = JSON.parse(savedData);
          this.populateForm();
        } catch (error) {
          console.error('Error loading saved data:', error);
        }
      }
    }
  }

  populateForm() {
    Object.entries(this.formData).forEach(([key, value]) => {
      const element = document.getElementById(key);
      if (element) {
        if (element.type === 'checkbox') {
          element.checked = value;
        } else {
          element.value = value;
        }
      }
    });

    // Update theme selector
    if (this.formData.wTheme) {
      const themeOption = document.querySelector(`[data-theme=\"${this.formData.wTheme}\"]`);
      if (themeOption) {
        document.querySelectorAll('.theme-option').forEach(opt => opt.classList.remove('selected'));
        themeOption.classList.add('selected');
      }
    }
  }

  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `wizard-notification ${type}`;
    notification.textContent = message;
    
    const container = document.querySelector('.wizard-container');
    if (container) {
      container.appendChild(notification);
      
      setTimeout(() => {
        notification.remove();
      }, 4000);
    }
  }

  setupValidation() {
    // Add CSS for validation states
    const style = document.createElement('style');
    style.textContent = `
      .field-error {
        border-color: #ff3b30 !important;
        box-shadow: 0 0 0 4px rgba(255, 59, 48, 0.1) !important;
      }
      
      .field-success {
        border-color: #34c759 !important;
        box-shadow: 0 0 0 4px rgba(52, 199, 89, 0.1) !important;
      }
      
      .field-message {
        font-size: 12px;
        margin-top: 4px;
        padding: 4px 8px;
        border-radius: 4px;
      }
      
      .field-message.error {
        color: #ff3b30;
        background: rgba(255, 59, 48, 0.1);
      }
      
      .field-message.success {
        color: #34c759;
        background: rgba(52, 199, 89, 0.1);
      }
      
      .saving-spinner {
        display: inline-block;
        width: 16px;
        height: 16px;
        border: 2px solid rgba(255,255,255,0.3);
        border-top: 2px solid white;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-right: 8px;
      }
      
      .wizard-notification {
        position: absolute;
        top: 20px;
        right: 20px;
        padding: 12px 16px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        z-index: 1000;
        animation: slideInRight 0.3s ease;
      }
      
      .wizard-notification.success {
        background: rgba(52, 199, 89, 0.9);
        color: white;
      }
      
      .wizard-notification.error {
        background: rgba(255, 59, 48, 0.9);
        color: white;
      }
      
      .wizard-notification.info {
        background: rgba(0, 122, 255, 0.9);
        color: white;
      }
      
      @keyframes slideInRight {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    `;
    document.head.appendChild(style);
  }
}

// Initialize Premium Setup Wizard
document.addEventListener('DOMContentLoaded', () => {
  window.premiumSetupWizard = new PremiumSetupWizard();
});